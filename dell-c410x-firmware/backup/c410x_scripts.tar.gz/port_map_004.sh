#!/bin/bash
# Program:
#   This program configure port map for Titanium.
# History:
#   2010/08/02 Mendel Initial.
#   2010/08/10        Modify "head" and "tail".
#   2010/08/12        Modify help part.
#   2010/10/31        Support 1:8.
# Command
#   sh ./port_map.sh bmc_ip bmc_un bmc_pw
#   sh ./port_map.sh 10.1.7.211 root root

bmc_ip=""
bmc_sn=""
bmc_pw=""
res=""
cfg=""
hex=""
dec=""
ctrl=0
pm1=0
pm2=0
pm3=0
pm4=0
cmd=""

function dec2hex()
{
  case $1 in
    "10")
      hex="a"
      ;;
    "11")
      hex="b"
      ;;
    "12")
      hex="c"
      ;;
    "13")
      hex="d"
      ;;
    "14")
      hex="e"
      ;;
    "15")
      hex="f"
      ;;
    *)
      hex=$1
      ;;
  esac
}

function hex2dec()
{
  case $1 in
    "a")
      dec="10"
      ;;
    "b")
      dec="11"
      ;;
    "c")
      dec="12"
      ;;
    "d")
      dec="13"
      ;;
    "e")
      dec="14"
      ;;
    "f")
      dec="15"
      ;;
    *)
      dec=$1
      ;;
  esac
}

function get_cfg()
{
  cmd="ipmitool -H "$bmc_ip" -I lan -U "$bmc_sn" -P "$bmc_pw" raw 0x34 0xc8 0x00 0x00"
#  echo $cmd
  res=$($cmd)
  cfg1=$(echo $res | tail --bytes=6 | head --bytes=2)
  cfg2=$(echo $res | tail --bytes=3)
#echo "get cfg1="$cfg1", get cfg2="$cfg2
}

function update_data()
{
  ctrl=$(echo $cfg1 | head --bytes=1)
#echo "ctrl="$ctrl

  hex=$(echo $cfg1 | tail --bytes=2)
#echo "portmap_hex="$hex
  hex2dec $hex
#echo "portmap_dec="$dec

  pm4=$(($dec%2))
#echo "pm4="$pm4

  dec=$(($dec/2))
  pm3=$(($dec%2))
#echo "pm3="$pm3

  dec=$(($dec/2))
  pm2=$(($dec%2))
#echo "pm2="$pm2

  dec=$(($dec/2))
  pm1=$(($dec%2))
#echo "pm1="$pm1

  pm81=$(echo $cfg2 | head --bytes=1)
#echo "pm81="$pm81

  pm82=$(echo $cfg2 | tail --bytes=2)
#echo "pm82="$pm82
}

function display()
{
  for i in $(seq 0 10)
  do
    echo
  done
  echo "Port mapping"
  if [ $ctrl != 1 ]; then
    echo "Current control by BMC"
  else
    echo "Current control by Jumper"
  fi
  echo "---------------------------------------"
  if [ $ctrl != 1 ] && [ $pm81 != 1 ]; then
    echo "iPass1 <==> PCIE1  PCIE2  PCIE3  PCIE4  PCIE13 PCIE14 PCIE15 PCIE16"
  else
    if [ $pm1 != 0 ]; then
      echo "iPass1 <==> PCIE1  PCIE15"
    else
      echo "iPass1 <==> PCIE1  PCIE2  PCIE15 PCIE16"
    fi
  fi
  if [ $ctrl != 1 ] && [ $pm81 != 1 ]; then
    echo "iPass2 <==> None"
  else
    if [ $pm2 != 0 ]; then
      echo "iPass2 <==> PCIE3  PCIE13"
    else
      echo "iPass2 <==> PCIE3  PCIE4  PCIE13 PCIE14"
    fi
  fi
  if [ $ctrl != 1 ] && [ $pm82 != 1 ]; then
    echo "iPass3 <==> PCIE5  PCIE6  PCIE7  PCIE8  PCIE9  PCIE10 PCIE11 PCIE12"
  else
    if [ $pm3 != 0 ]; then
      echo "iPass3 <==> PCIE5  PCIE11"
    else
      echo "iPass3 <==> PCIE5  PCIE6  PCIE11 PCIE12"
    fi
  fi
  if [ $ctrl != 1 ] && [ $pm82 != 1 ]; then
    echo "iPass4 <==> None"
  else
    if [ $pm4 != 0 ]; then
      echo "iPass4 <==> PCIE7  PCIE9"
    else
      echo "iPass4 <==> PCIE7  PCIE8  PCIE9  PCIE10"
    fi
  fi
  if [ $ctrl != 1 ] && [ $pm81 != 1 ]; then
    echo "iPass5 <==> None"
  else
    if [ $pm1 != 0 ]; then
      echo "iPass5 <==> PCIE2  PCIE16"
    else
      echo "iPass5 <==> None"
    fi
  fi
  if [ $ctrl != 1 ] && [ $pm81 != 1 ]; then
    echo "iPass6 <==> None"
  else
    if [ $pm2 != 0 ]; then
      echo "iPass6 <==> PCIE4  PCIE14"
    else
      echo "iPass6 <==> None"
    fi
  fi
  if [ $ctrl != 1 ] && [ $pm82 != 1 ]; then
    echo "iPass7 <==> None"
  else
    if [ $pm3 != 0 ]; then
      echo "iPass7 <==> PCIE6  PCIE12"
    else
      echo "iPass7 <==> None"
    fi
  fi
  if [ $ctrl != 1 ] && [ $pm82 != 1 ]; then
    echo "iPass8 <==> None"
  else
    if [ $pm4 != 0 ]; then
      echo "iPass8 <==> PCIE8  PCIE10"
    else
      echo "iPass8 <==> None"
    fi
  fi
  echo "======================================="
  if [ $ctrl != 1 ]; then
    echo "NoChange/Jumper/iPass1 ... iPass8"
    read -p "Change?(n/j/1/2/3/4/5/6/7/8):" cmd
  else
    echo "NoChange/BMC"
    read -p "Change?(n/b):" cmd
  fi
}

function change_data()
{
  if [ $ctrl != 1 ]; then
    case $cmd in
      "n")
        exit 0
        ;;
      "j")
        ctrl=1
        ;;
      "1")
        if [ $pm81 != 1 ]; then
          pm81=1
        else
          read -p "1:8?(y/n):" cmd
          if [ "$cmd" != "n" ]; then
            pm81=2
          else
            if [ $pm1 == 1 ]; then
              pm1=0
            else
              pm1=1
            fi
          fi
        fi
        ;;
      "2")
        if [ $pm81 != 1 ]; then
          pm81=1
        else
          if [ $pm2 == 1 ]; then
            pm2=0
          else
            pm2=1
          fi
        fi
        ;;
      "3")
        if [ $pm82 != 1 ]; then
          pm82=1
        else
          read -p "1:8?(y/n):" cmd
          if [ "$cmd" != "n" ]; then
            pm82=2
          else
            if [ $pm3 == 1 ]; then
              pm3=0
            else
              pm3=1
            fi
          fi
        fi
        ;;
      "4")
        if [ $pm82 != 1 ]; then
          pm82=1
        else
          if [ $pm4 == 1 ]; then
            pm4=0
          else
            pm4=1
          fi
        fi
        ;;
      "5")
        if [ $pm81 != 1 ]; then
          pm81=1
        else
          if [ $pm1 == 1 ]; then
            pm1=0
          else
            pm1=1
          fi
        fi
        ;;
      "6")
        if [ $pm81 != 1 ]; then
          pm81=1
        else
          if [ $pm2 == 1 ]; then
            pm2=0
          else
            pm2=1
          fi
        fi
        ;;
      "7")
        if [ $pm82 != 1 ]; then
          pm82=1
        else
          if [ $pm3 == 1 ]; then
            pm3=0
          else
            pm3=1
          fi
        fi
        ;;
      "8")
        if [ $pm82 != 1 ]; then
          pm82=1
        else
          if [ $pm4 == 1 ]; then
            pm4=0
          else
            pm4=1
          fi
        fi
        ;;
    esac
  else
    case $cmd in
      "n")
        exit 0
        ;;
      "b")
        ctrl=2
        ;;
    esac
  fi

#echo "-"$ctrl"-"$pm1"-"$pm2"-"$pm3"-"$pm4"-"$pm81"-"$pm82"-"
  dec=$(($pm1*8+$pm2*4+$pm3*2+$pm4))
#echo "dec="$dec
  dec2hex $dec
#echo "hex="$hex
  cfg1=$ctrl$hex
#echo "cfg1="$cfg1
  cfg2=$pm81$pm82
#echo "cfg2="$cfg2
}

function set_cfg()
{
  dec=$(($ctrl+8))
  dec2hex $dec
  n1=$hex
  dec=$(($pm1*8+$pm2*4+$pm3*2+$pm4))
  dec2hex $dec
  n2=$hex
#echo "set cfg1="$n1$n2
#echo "set cfg2="$pm81$pm82
  cmd="ipmitool -H "$bmc_ip" -I lan -U "$bmc_sn" -P "$bmc_pw" raw 0x34 0xc8 0x"$n1$n2" 0x"$pm81$pm82
#  echo $cmd
  res=$($cmd)
}

if [ $# != 3 ]; then
  echo "Parameter error"
  echo "sh ./port_map.sh bmc_ip bmc_un bmc_pw"
  exit 0
fi

bmc_ip=$1
bmc_sn=$2
bmc_pw=$3
while [ 1 ]
do
  get_cfg
  update_data
  display
  change_data
  set_cfg
done

exit 0

