
Use port_map.sh to change the port map of the C410x.

NOTE: The C410x will require a power cycle on the entire system before the port map is updated.  All host should be rebooted at the same time.

The BMC IP address, Username, and Password are required to run the script.

# ./port_map.sh bmc_ip bmc_un bmc_pw

# ./port_map.sh 198.168.12.146 username password

The current iPass port map to PCIE port will be listed.
At the "Change? (n/j/1/2/3/4/5/6/7/8): prompt enter the corresponding iPass port number that needs to be changed.

For example:
If iPass1 port is configured as a 1:4 
    iPass1 <==> PCIE1  PCIE2  PCIE15 PCIE16
    iPass5 <==> None
To configure iPass1 port as a 1:2 enter "1".
The PCIE port assigmnet for iPass1 and iPass5 will be updated accordingly.
    iPass1 <==> PCIE1  PCIE15
    iPass5 <==> PCIE2  PCIE16

Press "n" to exit


Use fw_upgrade.sh to udate the BMC firmware on the C410x.

The BMC IP address, Username, Password, and Firmware Image Path are required to run the script.

# ./fw_upgrade.sh bmc_ip bmc_un bmc_pw fw_path

# ./port_map.sh 198.168.12.146 username password tftp://192.168.12.1/BM3P110.pec

NOTE: The full TFTP path for the firmware image file is required.

