**********************************************************************
                      Release Notes for
              CloudEdge Local Firmware Update Utility
                 For DOS, Windows and Linux

              Copyright (C) 2010 Dell Inc.
                    All rights reserved.

Reproduction in any manner whatsoever without the written permission 
of Dell Inc. is strictly forbidden.

Trademarks used in this text: "Dell" and "CloudEdge" are trademarks 
of Dell Inc.; "Microsoft" and "Windows" are registered trademarks of 
Microsoft Corporation; "Red Hat" is a registered trademark of 
Red Hat, Inc.)

Other trademarks and trade names may be used in this document to 
refer to either the entities claiming the marks and names or their 
products. Dell Inc. disclaims any proprietary interest in trademarks 
and trade names other than its own.

January 2010
**********************************************************************

======================================================================
CONTENTS
======================================================================
    1.0 Read Me First
    2.0 Manifest
    3.0 Tool Usage
    4.0 Verifying and Identifying

======================================================================
1.0 Read Me First
======================================================================
Function:
    Update firmware to the target device via webGUI/FTP/TFTP/HTTP 
    interface.

Utility:
    Internet Browser.
    IPMITOOL

======================================================================
2.0 Manifest
======================================================================
This package contains the following files.

\doc\AccessMACaddress.doc - SOP, access MAC address via serial channel
     communication.doc    - Network communication
     update_fw.doc        - SOP, Generate update F/W command for LAN
     update_fw_remote.doc - SOP, update F/W via LAN
     update_fw_web.doc    - SOP, update F/W via web GUI

\fw_img\BM3Pxxx.pec       - F/W, update use

\others\doc\update_fru.doc- SOP, Generate update FRU command for LAN

\others\fru\BM3Pxxx.fru   - FRU

\others\fw_bin\BM3Pxxx.bin- F/W, manufacture use

\tool\RE_UP_FW.EXE        - Generate update F/W command
      SC_TRANS.EXE        - Generate update FRU command
      UD_FRU2.EXE         - Generate update FRU data

======================================================================
3.0 Tool Usage
======================================================================   
Internet Browser
    1. Program Browser.
    2. Input BMC IP to URL field.
    3. Login, default user name "root" and default password "root".
    4. Change to update firmware page.
        a. Select firmware file.
            Click browse button to select file to update.
        b. Update Type
        c. Preserve Configuration
    5. After update finish, reset system.

IPMITOOL
    Example configure:
    BMC IP              =>10.1.7.19
    BMC account name    =>root
    BMC account password=>root
    TFTP server IP      =>10.1.7.136
    Firmware file name  =>firmimg.ast2050.dcs
    Firmware path       =>tftp://10.1.7.136/firmimg.ast2050.dcs

    The meaning of this command is:
    |---------------------------------------------|
    |Extended Configuration Command   NetFn  CMD  |
    |Reserved Extended Configuration  30h    01h  |
    |Set Extended Configuration	      30h    03h  |
    |Update Firmware                  08h    01h  |
    |Get Update Status                08h    02h  |
    |---------------------------------------------|

    1. Reserved Extended Configuration
    |----------------------------------------------------------------|
    |Request Data                                                    |
    |  byte    data field                                            |
    |  -       -                                                     |
    |----------------------------------------------------------------|
    |Response Data                                                   |
    |  byte    data field                                            |
    |  1       Completion Code                                       |
    |  2       Reservation ID, 00h is reserved.                      |
    |          The BMC shall automatically cancel the Reservation ID |
    |          if the value is not used in sub-sequential Get/Set    |
    |          Extended Configuration commands within 60 seconds.    |
    |----------------------------------------------------------------|
    Ex:
    Request:ipmitool -H 10.1.7.19 -I lan -U "root" -P "root" raw 0x30 
            0x01
    Response:byte1=>Reservation ID.

    2. Set Extended Configuration - Set the URI of the image file
    |----------------------------------------------------------------|
    |Request Data                                                    |
    |  byte    data field                                            |
    |  1       Reservation ID                                        |
    |  2       Configuration ID                                      |
    |  3       Attribute ID.                                         |
    |  4       Index (used by table object only)                     |
    |  5       Data Offset to write-LSB                              |
    |  6       Data Offset to write-MSB                              |
    |  7       In progress                                           |
    |          [7:4] reserved                                        |
    |          [3:0] in progress                                     |
    |            0-in progress                                       |
    |            1-last configuration data being transferred in this |
    |              this request                                      |
    |  8:N     Data to be written                                    |
    |          If byte5 and byte6 are 0x00, byte8 is total data      |
    |          length.                                               |
    |----------------------------------------------------------------|
    |Response Data                                                   |
    |  byte    data field                                            |
    |  1       Completion Code                                       |
    |            01h:no more data                                    |
    |  2       Bytes written-count is 1 based                        |
    |----------------------------------------------------------------|
    Ex:
    a. Request:ipmitool -H 10.1.7.19 -I lan -U "root" -P "root" raw 
               0x30 0x03 0x01 0x10 0x03 0x00 0x00 0x00 0x00 0x25 0x74 
               0x66 0x74 0x70 0x3A 0x2F 0x2F 0x31 0x30 0x2E 0x31 0x2E 
               0x37 0x2E 0x31 0x33 0x36 0x2F
       (tftp://10.1.7.136/)
       Response:byte1=>Bytes written.
    b. Request:ipmitool -H 10.1.7.19 -I lan -U "root" -P "root" raw 
               0x30 0x03 0x01 0x10 0x03 0x00 0x13 0x00 0x01 0x66 0x69 
               0x72 0x6D 0x69 0x6D 0x67 0x2E 0x61 0x73 0x74 0x32 0x30 
               0x35 0x30 0x2E 0x64 0x63 0x73
       (firmimg.ast2050.dcs)
       Response:byte1=>Bytes written.

    3. Update Firmware
    |----------------------------------------------------------------|
    |Request Data                                                    |
    |  byte    data field                                            |
    |  1       Interface Used: Specifies the interface which the     |
    |          image is transmitted through:                         |
    |            00h:System interface, such as KCS                   |
    |            01h:Networking, such as TFTP, FTP or HTTP           |
    |            02h:USB MSC, Legacy                                 |
    |            03h:USB init command                                |
    |  2       Update Type                                           |
    |          [7]-Force Update                                      |
    |            0:Normal update.                                    |
    |              An update operation will occur only when the BMC  |
    |              validate the target board, target product and     |
    |              version number.                                   |
    |            1:Forced update.                                    |
    |              Forced update make the BMC update the image       |
    |              without validate target board, target product and |
    |              version number.                                   |
    |          [6:3]-reserved                                        |
    |          [2:0]-Entity:Indicates the physical controller this   |
    |                image is associated. This is based on the       |
    |                Entity attribute of Configuration 0Fh in        |
    |                Extended Configurations.                        |
    |                0: BMC                                          |
    |                1: SYSTEM(BIOS)                                 |
    |                2: PDB                                          |
    |                3: FCB                                          |
    |  3:14    Install Options                                       |
    |          This field is optional. If present, it contains the   |
    |          list of options that control the installation         |
    |          procedure. The meanings of the numbers are specific to|
    |          the vendor.                                           |
    |----------------------------------------------------------------|
    |Response Data                                                   |
    |  byte    data field                                            |
    |  1       Completion Code                                       |
    |  2       Task ID                                               |
    |----------------------------------------------------------------|
    Ex:
    Request:ipmitool -H 10.1.7.19 -I lan -U "root" -P "root" raw 0x08 
            0x01 0x01 0x80
    Response:byte1=>task ID.

    4. Update progressing(about 5 minutes).

    5. Get Update Status
    |----------------------------------------------------------------|
    |Request Data                                                    |
    |  byte    data field                                            |
    |  1       Task ID                                               |
    |----------------------------------------------------------------|
    |Response Data                                                   |
    |  byte    data field                                            |
    |  1       Completion Code                                       |
    |  2       Status                                                |
    |            00h:Transmitting Image                              |
    |            01h:Validating Image                                |
    |            02h:Programming                                     |
    |            03h:Ready to Accept Image                           |
    |            80h:General error                                   |
    |            81h:Cannot establish connection                     |
    |            82h:Path not found                                  |
    |            83h:Transmission Abort                              |
    |            84h:Checksum error                                  |
    |            85h:Incorrect Platform                              |
    |            FFh:Completed                                       |
    |  3       Progression Indicator. This field is optional. If     |
    |          present, its value indicates the current progress of  |
    |          the status specified in Status byte.                  |
    |----------------------------------------------------------------|
    Ex:Use this command to get Update progress. When Update 
       completed, this command will return 0xFF.
    Request:ipmitool -H 10.1.7.19 -I lan -U "root" -P "root" raw 0x08 
            0x02 0x01
            (Task ID)
    Response:byte1=>status ID.

    6. BMC Cold reset
       Update complete, It is require a BMC cold reset.
    Request:ipmitool -H 10.1.7.19 -I lan -U "root" -P "root" raw 0x06 
            0x02

======================================================================
4.0 Verifying and Identifying
======================================================================
After finish BMC update, user can issue below process to check the BMC
 firmware version information.

Internet Browser
    1. Program Browser.
    2. Input BMC IP to URL field.
    3. Login, default user name "root" and default password "root".
    4. Firmware version show at home page.

IPMITOOL
    Example configure:
    BMC IP              =>10.1.7.19
    BMC account name    =>root
    BMC account password=>root
    1. ipmitool -H 10.1.7.19 -I lan -U "root" -P "root" raw 0x06 0x01
       Response:byte3=>major revision, byte4=>minor revision.

