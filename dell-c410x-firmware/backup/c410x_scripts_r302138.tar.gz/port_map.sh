#!/bin/bash
# Program:
#   This program configure port map for Titanium.
# History:
#   2010/08/02 Mendel Initial.
#   2010/08/10        Modify "head" and "tail".
#   2010/08/12        Modify help part.
# Command
#   sh ./port_map.sh bmc_ip bmc_sn bmc_pw
#   sh ./port_map.sh 10.1.7.211 root root

bmc_ip=""
bmc_sn=""
bmc_pw=""
res=""
cfg=""
hex=""
dec=""
ctrl=0
pm1=0
pm2=0
pm3=0
pm4=0
cmd=""

function dec2hex()
{
  case $1 in
    "10")
      hex="a"
      ;;
    "11")
      hex="b"
      ;;
    "12")
      hex="c"
      ;;
    "13")
      hex="d"
      ;;
    "14")
      hex="e"
      ;;
    "15")
      hex="f"
      ;;
    *)
      hex=$1
      ;;
  esac
}

function hex2dec()
{
  case $1 in
    "a")
      dec="10"
      ;;
    "b")
      dec="11"
      ;;
    "c")
      dec="12"
      ;;
    "d")
      dec="13"
      ;;
    "e")
      dec="14"
      ;;
    "f")
      dec="15"
      ;;
    *)
      dec=$1
      ;;
  esac
}

function get_cfg()
{
  cmd="ipmitool -H "$bmc_ip" -I lan -U "$bmc_sn" -P "$bmc_pw" raw 0x34 0xc8 0x00"
#  echo $cmd
  res=$($cmd)
  cfg=$(echo $res | tail --bytes=3)
#echo "get cfg="$cfg
}

function update_data()
{
  ctrl=$(echo $cfg | head --bytes=1)
#echo "ctrl="$ctrl

  hex=$(echo $cfg | tail --bytes=2)
#echo "portmap_hex="$hex
  hex2dec $hex
#echo "portmap_dec="$dec

  pm4=$(($dec%2))
#echo "pm4="$pm4

  dec=$(($dec/2))
  pm3=$(($dec%2))
#echo "pm3="$pm3

  dec=$(($dec/2))
  pm2=$(($dec%2))
#echo "pm2="$pm2

  dec=$(($dec/2))
  pm1=$(($dec%2))
#echo "pm1="$pm1
}

function display()
{
  for i in $(seq 0 10)
  do
    echo
  done
  echo "Port mapping"
  if [ $ctrl != 1 ]; then
    echo "Current control by BMC"
  else
    echo "Current control by Jumper"
  fi
  echo "---------------------------------------"
  if [ $pm1 != 0 ]; then
    echo "iPass1 <==> PCIE1  PCIE15"
  else
    echo "iPass1 <==> PCIE1  PCIE2  PCIE15 PCIE16"
  fi
  if [ $pm2 != 0 ]; then
    echo "iPass2 <==> PCIE3  PCIE13"
  else
    echo "iPass2 <==> PCIE3  PCIE4  PCIE13 PCIE14"
  fi
  if [ $pm3 != 0 ]; then
    echo "iPass3 <==> PCIE5  PCIE11"
  else
    echo "iPass3 <==> PCIE5  PCIE6  PCIE11 PCIE12"
  fi
  if [ $pm4 != 0 ]; then
    echo "iPass4 <==> PCIE7  PCIE9"
  else
    echo "iPass4 <==> PCIE7  PCIE8  PCIE9  PCIE10"
  fi
  if [ $pm1 != 0 ]; then
    echo "iPass5 <==> PCIE2  PCIE16"
  else
    echo "iPass5 <==> None"
  fi
  if [ $pm2 != 0 ]; then
    echo "iPass6 <==> PCIE4  PCIE14"
  else
    echo "iPass6 <==> None"
  fi
  if [ $pm3 != 0 ]; then
    echo "iPass7 <==> PCIE6  PCIE12"
  else
    echo "iPass7 <==> None"
  fi
  if [ $pm4 != 0 ]; then
    echo "iPass8 <==> PCIE8  PCIE10"
  else
    echo "iPass8 <==> None"
  fi
  echo "======================================="
  if [ $ctrl != 1 ]; then
    echo "NoChange/Jumper/iPass1 ... iPass8"
    read -p "Change?(n/j/1/2/3/4/5/6/7/8):" cmd
  else
    echo "NoChange/BMC"
    read -p "Change?(n/b):" cmd
  fi
}

function change_data()
{
  if [ $ctrl != 1 ]; then
    case $cmd in
      "n")
        exit 0
        ;;
      "j")
        ctrl=1
        ;;
      "1")
        if [ $pm1 == 1 ]; then
          pm1=0
        else
          pm1=1
        fi
        ;;
      "2")
        if [ $pm2 == 1 ]; then
          pm2=0
        else
          pm2=1
        fi
        ;;
      "3")
        if [ $pm3 == 1 ]; then
          pm3=0
        else
          pm3=1
        fi
        ;;
      "4")
        if [ $pm4 == 1 ]; then
          pm4=0
        else
          pm4=1
        fi
        ;;
      "5")
        if [ $pm1 == 1 ]; then
          pm1=0
        else
          pm1=1
        fi
        ;;
      "6")
        if [ $pm2 == 1 ]; then
          pm2=0
        else
          pm2=1
        fi
        ;;
      "7")
        if [ $pm3 == 1 ]; then
          pm3=0
        else
          pm3=1
        fi
        ;;
      "8")
        if [ $pm4 == 1 ]; then
          pm4=0
        else
          pm4=1
        fi
        ;;
    esac
  else
    case $cmd in
      "n")
        exit 0
        ;;
      "b")
        ctrl=2
        ;;
    esac
  fi

#echo "-"$ctrl"-"$pm1"-"$pm2"-"$pm3"-"$pm4"-"
  dec=$(($pm1*8+$pm2*4+$pm3*2+$pm4))
#echo "dec="$dec
  dec2hex $dec
#echo "hex="$hex
  cfg=$ctrl$hex
#echo "cfg="$cfg
}

function set_cfg()
{
  dec=$(($ctrl+8))
  dec2hex $dec
  n1=$hex
  dec=$(($pm1*8+$pm2*4+$pm3*2+$pm4))
  dec2hex $dec
  n2=$hex
#echo "set cfg="$n1$n2
  cmd="ipmitool -H "$bmc_ip" -I lan -U "$bmc_sn" -P "$bmc_pw" raw 0x34 0xc8 0x"$n1$n2
#  echo $cmd
  res=$($cmd)
}

if [ $# != 3 ]; then
  echo "Parameter error"
  echo "sh ./port_map.sh bmc_ip bmc_sn bmc_pw"
  exit 0
fi

bmc_ip=$1
bmc_sn=$2
bmc_pw=$3
while [ 1 ]
do
  get_cfg
  update_data
  display
  change_data
  set_cfg
done

exit 0

