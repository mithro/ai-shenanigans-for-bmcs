#!/bin/bash
# Program:
#   This program update firmware for Titanium.
# History:
#   2010/07/28 Mendel Initial.
#   2010/08/10        Modify "head", "tail" and "cut".
#   2010/08/12        Modify help part.
# Command
#   sh ./fw_upgrade.sh bmc_ip bmc_sn bmc_pw fw_path
#   sh ./fw_upgrade.sh 10.1.7.211 root root tftp://10.1.7.136/firmimg.ast2050.dcs

cmd=""
res=""
rid=""
fw_len_dec=0
fw_len_hex="00"
i=0
offset=0
hex="0x00"
code=""
old_code=""

function c2h()
{
  case $1 in
    \ )
      hex=0x20
      ;;
    \!)
      hex=0x21
      ;;
    \")
      hex=0x22
      ;;
    \#)
      hex=0x23
      ;;
    \$)
      hex=0x24
      ;;
    \%)
      hex=0x25
      ;;
    \&)
      hex=0x26
      ;;
    \')
      hex=0x27
      ;;
    \()
      hex=0x28
      ;;
    \))
      hex=0x29
      ;;
    \*)
      hex=0x2A
      ;;
    \+)
      hex=0x2B
      ;;
    \,)
      hex=0x2C
      ;;
    \-)
      hex=0x2D
      ;;
    \.)
      hex=0x2E
      ;;
    \/)
      hex=0x2F
      ;;
    "0")
      hex=0x30
      ;;
    "1")
      hex=0x31
      ;;
    "2")
      hex=0x32
      ;;
    "3")
      hex=0x33
      ;;
    "4")
      hex=0x34
      ;;
    "5")
      hex=0x35
      ;;
    "6")
      hex=0x36
      ;;
    "7")
      hex=0x37
      ;;
    "8")
      hex=0x38
      ;;
    "9")
      hex=0x39
      ;;
    \:)
      hex=0x3A
      ;;
    \;)
      hex=0x3B
      ;;
    \<)
      hex=0x3C
      ;;
    \=)
      hex=0x3D
      ;;
    \>)
      hex=0x3E
      ;;
    \?)
      hex=0x3F
      ;;
    \@)
      hex=0x40
      ;;
    "A")
      hex=0x41
      ;;
    "B")
      hex=0x42
      ;;
    "C")
      hex=0x43
      ;;
    "D")
      hex=0x44
      ;;
    "E")
      hex=0x45
      ;;
    "F")
      hex=0x46
      ;;
    "G")
      hex=0x47
      ;;
    "H")
      hex=0x48
      ;;
    "I")
      hex=0x49
      ;;
    "J")
      hex=0x4A
      ;;
    "K")
      hex=0x4B
      ;;
    "L")
      hex=0x4C
      ;;
    "M")
      hex=0x4D
      ;;
    "N")
      hex=0x4E
      ;;
    "O")
      hex=0x4F
      ;;
    "P")
      hex=0x50
      ;;
    "Q")
      hex=0x51
      ;;
    "R")
      hex=0x52
      ;;
    "S")
      hex=0x53
      ;;
    "T")
      hex=0x54
      ;;
    "U")
      hex=0x55
      ;;
    "V")
      hex=0x56
      ;;
    "W")
      hex=0x57
      ;;
    "X")
      hex=0x58
      ;;
    "Y")
      hex=0x59
      ;;
    "Z")
      hex=0x5A
      ;;
    \[)
      hex=0x5B
      ;;
    \\)
      hex=0x5C
      ;;
    \])
      hex=0x5D
      ;;
    \^)
      hex=0x5E
      ;;
    \_)
      hex=0x5F
      ;;
    \`)
      hex=0x60
      ;;
    "a")
      hex=0x61
      ;;
    "b")
      hex=0x62
      ;;
    "c")
      hex=0x63
      ;;
    "d")
      hex=0x64
      ;;
    "e")
      hex=0x65
      ;;
    "f")
      hex=0x66
      ;;
    "g")
      hex=0x67
      ;;
    "h")
      hex=0x68
      ;;
    "i")
      hex=0x69
      ;;
    "j")
      hex=0x6A
      ;;
    "k")
      hex=0x6B
      ;;
    "l")
      hex=0x6C
      ;;
    "m")
      hex=0x6D
      ;;
    "n")
      hex=0x6E
      ;;
    "o")
      hex=0x6F
      ;;
    "p")
      hex=0x70
      ;;
    "q")
      hex=0x71
      ;;
    "r")
      hex=0x72
      ;;
    "s")
      hex=0x73
      ;;
    "t")
      hex=0x74
      ;;
    "u")
      hex=0x75
      ;;
    "v")
      hex=0x76
      ;;
    "w")
      hex=0x77
      ;;
    "x")
      hex=0x78
      ;;
    "y")
      hex=0x79
      ;;
    "z")
      hex=0x7A
      ;;
    \{)
      hex=0x7B
      ;;
    \|)
      hex=0x7C
      ;;
    \})
      hex=0x7D
      ;;
    \~)
      hex=0x7E
      ;;
  esac
}

function cnt_fw_len()
{
  tmp=""
  n1=0
  n2=0
  tmp=$(echo $1 | cut --characters=$fw_len_dec-$fw_len_dec)
  while [ "$tmp" != "" ]
  do
    fw_len_dec=$(($fw_len_dec+1))
    n1=$(($n1+1))
    if [ $n1 == 16 ]; then
      n1=0
      n2=$(($n2+1))
    fi
    tmp=$(echo $1 | cut --characters=$fw_len_dec-$fw_len_dec)
  done
  fw_len_dec=$(($fw_len_dec-1))
  if [ $n1 == 0 ]; then
    n1=15
    n2=$(($n2-1))
  else
    n1=$(($n1-1))
  fi
  case $n1 in
    "10")
      n1="A"
      ;;
    "11")
      n1="B"
      ;;
    "12")
      n1="C"
      ;;
    "13")
      n1="D"
      ;;
    "14")
      n1="E"
      ;;
    "15")
      n1="F"
      ;;
  esac
  case $n2 in
    "10")
      n2="A"
      ;;
    "11")
      n2="B"
      ;;
    "12")
      n2="C"
      ;;
    "13")
      n2="D"
      ;;
    "14")
      n2="E"
      ;;
    "15")
      n2="F"
      ;;
  esac
  fw_len_hex=$n2$n1
}

if [ $# != 4 ]; then
  echo "Parameter error"
  echo "sh ./fw_upgrade.sh bmc_ip bmc_sn bmc_pw fw_path"
  exit 0
fi

echo "Start upgrade firmware"
cmd="ipmitool -H "$1" -I lan -U "$2" -P "$3" raw 0x30 0x01"
#echo $cmd
res=$($cmd)
sleep 5
rid="0x"$(echo $res | tail --bytes=3)
#echo "RID="$rid

echo "Initial"
cnt_fw_len $4
for i in $(seq 0 $fw_len_dec)
do
  if [ $i == 0 ]; then
    cmd="ipmitool -H "$1" -I lan -U "$2" -P "$3" raw 0x30 0x03 "$rid" 0x10 0x03 0x00 0x"$offset"0 0x00 0x00 0x"$fw_len_hex
  elif [ $((i%16)) == 0 ]; then
#    echo $cmd
    res=$($cmd)
    sleep 5
    offset=$(($offset+1))
    if [ $(($fw_len_dec-$i-16)) -gt 0 ]; then
      cmd="ipmitool -H "$1" -I lan -U "$2" -P "$3" raw 0x30 0x03 "$rid" 0x10 0x03 0x00 0x"$offset"0 0x00 0x00"
    else
      cmd="ipmitool -H "$1" -I lan -U "$2" -P "$3" raw 0x30 0x03 "$rid" 0x10 0x03 0x00 0x"$offset"0 0x00 0x01"
    fi
    c2h $(echo $4 | cut --characters=$i-$i)
    cmd=$cmd" "$hex
  else
    c2h $(echo $4 | cut --characters=$i-$i)
    cmd=$cmd" "$hex
  fi
done
#echo $cmd
res=$($cmd)
sleep 5

cmd="ipmitool -H "$1" -I lan -U "$2" -P "$3" raw 0x08 0x01 0x01 0x80"
#echo $cmd
res=$($cmd)
sleep 5
rid="0x"$(echo $res | tail --bytes=3)
#echo "TID="$rid

old_code="XX"
while [ $old_code != "ff" ]
do
  cmd="ipmitool -H "$1" -I lan -U "$2" -P "$3" raw 0x08 0x02 "$rid
#  echo $cmd
  res=$($cmd)
  sleep 5
  code=$(echo $res | tail --bytes=3)
  if [ $code != $old_code ]; then
    case $code in
      "00")
        echo "Transmitting image"
        ;;
      "01")
        echo "Validating image"
        ;;
      "02")
        echo "Programming"
        ;;
      "03")
        echo "Ready to accept image"
        ;;
      "80")
        echo "General error"
        exit 1
        ;;
      "81")
        echo "Cannot establish connection"
        exit 1
        ;;
      "82")
        echo "Path not found"
        exit 1
        ;;
      "83")
        echo "Transmission abort"
        exit 1
        ;;
      "84")
        echo "Checksum error"
        exit 1
        ;;
      "85")
        echo "Incorrect platform"
        exit 1
        ;;
      "ff")
        echo "Completed"
        ;;
      *)
        echo "Unknow status"
        exit 1
        ;;
    esac
  fi
  old_code=$code
done

cmd="ipmitool -H "$1" -I lan -U "$2" -P "$3" raw 0x06 0x02"
#echo $cmd
res=$($cmd)
sleep 5
echo "BMC restart ..."

sleep 40

cmd="ipmitool -H "$1" -I lan -U "$2" -P "$3" raw 0x06 0x01"
#echo $cmd
res=$($cmd)
sleep 5
code=$(echo $res | head --bytes=2 | tail --bytes=3)
if [ $code == "20" ]; then
  echo "BMC restart success"
else
  echo "BMC restart failure"
fi

exit 0

